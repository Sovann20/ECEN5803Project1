var searchData=
[
  ['description_3a_20header_20file_20for_20all_20globals_0',['&amp;ndash; Functional Description:  Header file for all globals',['../shared_8h.html#autotoc_md16',1,'']]],
  ['description_3a_20see_20below_1',['Functional Description: See below',['../_monitor_8cpp.html#autotoc_md10',1,'']]],
  ['designed_20for_3a_20university_20of_20colorado_20at_20boulder_2',['designed for: university of colorado at boulder',['../main_8cpp.html#autotoc_md1',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../_monitor_8cpp.html#autotoc_md7',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../shared_8h.html#autotoc_md13',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../timer0_8cpp.html#autotoc_md19',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../_u_a_r_t__poll_8cpp.html#autotoc_md24',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder']]]
];
