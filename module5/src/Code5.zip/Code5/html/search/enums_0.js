var searchData=
[
  ['boolean_0',['boolean',['../shared_8h.html#a7c6368b321bd9acd0149b030bb8275ed',1,'shared.h']]]
];
