/**----------------------------------------------------------------------------
             \file Monitor.cpp
--                                                                           --
--              ECEN 5003 Mastering Embedded System Architecture             --
--                  Project 1 Module 4                                       --
--                Microcontroller Firmware                                   --
--                      Monitor.cpp                                            --
--                                                                           --
-------------------------------------------------------------------------------
--
--  Designed for:  University of Colorado at Boulder
--               
--                
--  Designed by:  Tim Scherr
--  Revised by:  Michael Starks and Sovann Chak
-- 
-- Version: 2.0
-- Date of current revision:  2023-10-15   
-- Target Microcontroller: ST STM32F401RE 
-- Tools used:  ARM mbed compiler
--              ARM mbed SDK
--              ST Nucleo STM32F401RE Board
--               
-- 
   Functional Description: See below 
--
--      Copyright (c) 2015, 2022 Tim Scherr All rights reserved.
--
*/              

#include <stdio.h>
#include "shared.h"

register int R0 __ASM("r0");
register int R1 __ASM("r1");
register int R2 __ASM("r2");
register int R3 __ASM("r3");
register int R4 __ASM("r4");
register int R5 __ASM("r5");
register int R6 __ASM("r6");
register int R7 __ASM("r7");
register int R8 __ASM("r8");
register int R9 __ASM("r9");
register int R10 __ASM("r10");
//register int R11 __ASM("r11");
//register int R12 __ASM("r12");
register int R13 __ASM("r13");
register int R14 __ASM("r14");
register int R15 __ASM("r15");

uchar8_t startbuf[8];
uchar8_t endbuf[8];

//*****************************************************************************/
/// \fn void set_display_mode(void)   
///
///  \brief - Writes the various mode options and their descriptions 
///           to the UART so the user can easily select which mode
/// 				  they would like to run in.
//*****************************************************************************/
/****************      ECEN 5803 add code as indicated   **********************/
void set_display_mode(void)   
{
  UART_direct_msg_put("\r\nSelect Mode");
  UART_direct_msg_put("\r\n Hit NOR - Normal");
  UART_direct_msg_put("\r\n Hit QUI - Quiet");
  UART_direct_msg_put("\r\n Hit DEB - Debug" );
	UART_direct_msg_put("\r\n Hit MEM start_hexaddr end_hexaddr - Memory Read" );
	UART_direct_msg_put("\r\n Hit STK - Stacktrace" );
	UART_direct_msg_put("\r\n Hit GEN - General" );
  UART_direct_msg_put("\r\n Hit V - Version#");
	UART_direct_msg_put("\r\n Hit HEL - Help\r\n");
  UART_direct_msg_put("\r\nSelect:  ");
  
}


//*****************************************************************************/
/// \fn void chk_UART_msg(void) 
///
///  \brief - fills a message buffer until return is encountered, then calls
///           message processing
//*****************************************************************************/
void chk_UART_msg(void)    
{
   uchar8_t j;
   while( UART_input() )      // becomes true only when a byte has been received
   {                                    // skip if no characters pending
      j = UART_get();                 // get next character
			
      if( j == '\r' )          // on a enter (return) key press
      {                // complete message (all messages end in carriage return)
         UART_msg_put("->");
         UART_msg_process();
      }
      else 
      {
         if ((j != 0x02))         // if not ^B
         {                             // if not command, then   
            UART_put(j);              // echo the character
						display_timer=0;
         }

         if( j == '\b' ) 
         {                             // backspace editor
            if( msg_buf_idx != 0) 
            {                       // if not 1st character then destructive 
               UART_msg_put(" \b");// backspace
               msg_buf_idx--;
            }
         }
         else if( (msg_buf[0] != 'M' && msg_buf_idx >= MSG_BUF_SIZE) || 
					        (msg_buf[0] == 'M' && msg_buf_idx > 21) )  
         {                                // check message length too large
            UART_msg_put("\r\nToo Long!");
            msg_buf_idx = 0;
         }
         else if ((display_mode == QUIET) && (msg_buf[0] != 0x02) && 
                  (msg_buf[0] != 'D') && (msg_buf[0] != 'N') &&				 
                  (msg_buf[0] != 'V') && (msg_buf[0] != 'S') &&
									(msg_buf[0] != 'M') && (msg_buf[0] != 'G') &&
									(msg_buf[0] != 'H') && (msg_buf_idx != 0))
         {                          // if first character is bad in Quiet mode
            msg_buf_idx = 0;        // then start over
         }
         else 
				 {                        // not complete message, store character
					 
					 if(msg_buf[0] == 'M' && msg_buf_idx > 2)
					 {
						 if(msg_buf_idx >= 4 && msg_buf_idx <= 11)
						 {
							 startbuf[msg_buf_idx-4] = j;
						 }
						 else if(msg_buf_idx >= 13 && msg_buf_idx <= 20)
						 {
							 endbuf[msg_buf_idx-13] = j;
						 }
					 }
					 else
					 {
						 msg_buf[msg_buf_idx] = j;
					 }
					 
					 msg_buf_idx++;
					 
            if (msg_buf[0] != 'M' && msg_buf_idx > 2)
            {
               UART_msg_process();
            }
						// keep processing since mem has larger arguments
						else if(msg_buf[0] == 'M' && msg_buf_idx > 20)
						{
							UART_msg_process();
						}
         }
      }
   }
}

//*****************************************************************************/
///  \fn void UART_msg_process(void) 
///
///  \brief - UART Input Message Processing
//*****************************************************************************/
void UART_msg_process(void)
{
   uchar8_t chr,err=0;
//   unsigned char  data;

   if( (chr = msg_buf[0]) <= 0x60 ) 
   {      // Upper Case
      switch( chr ) 
      {
         case 'D':
            if((msg_buf[1] == 'E') && (msg_buf[2] == 'B') && (msg_buf_idx == 3)) 
            {
               display_mode = DEBUG;
               UART_msg_put("\r\nMode=DEBUG\n");
               display_timer = 0;
            }
            else
               err = 1;
            break;

         case 'N':
            if((msg_buf[1] == 'O') && (msg_buf[2] == 'R') && (msg_buf_idx == 3)) 
            {
               display_mode = NORMAL;
               UART_msg_put("\r\nMode=NORMAL\n");
               //display_timer = 0;
            }
            else
               err = 1;
            break;

         case 'Q':
            if((msg_buf[1] == 'U') && (msg_buf[2] == 'I') && (msg_buf_idx == 3)) 
            {
               display_mode = QUIET;
               UART_msg_put("\r\nMode=QUIET\n");
               display_timer = 0;
            }
            else
               err = 1;
            break;

         case 'V':
            display_mode = VERSION;
            UART_msg_put("\r\n");
            UART_msg_put( CODE_VERSION ); 
            UART_msg_put("\r\nSelect  ");
            display_timer = 0;
            break;
				 case 'S':
					 if((msg_buf[1] == 'T') && (msg_buf[2] == 'K') && (msg_buf_idx == 3)) 
            {
               display_mode = STACKTRACE;
               UART_msg_put("\r\nMode=Stacktrace\n");
               display_timer = 0;
            }
            else
               err = 1;
            break;
				 case 'M':
           	if((msg_buf[1] == 'E') && (msg_buf[2] == 'M') && (msg_buf_idx >= 20)) 
            {
               display_mode = MEMREAD;
               UART_msg_put("\r\nMode=Memory Read\n");
               display_timer = 0;
            }
            else
               err = 1;
            break;
         case 'G':
					 if((msg_buf[1] == 'E') && (msg_buf[2] == 'N') && (msg_buf_idx == 3))  
					 {
               display_mode = GENERAL;
               UART_msg_put("\r\nMode=General\n");
               display_timer = 0;
           }           
					 else
					 {
						err = 1;
					 }
				 case 'H':
					 if((msg_buf[1] == 'E') && (msg_buf[2] == 'L') && (msg_buf_idx == 3))  
					 {
               display_mode = HELP;
               UART_msg_put("\r\nMode=HELP\n");
               display_timer = 0;
           }           
					 else
					 {
						err = 1;
					 }
						break;
						
         default:
            err = 1;
      }
   }
   else 
   {                                 
		 // Lower Case
      switch( chr ) 
      {
        default:
         err = 1;
      }
   }

   if( err == 1 )
   {
      UART_msg_put("\n\rEntry Error!");
		  msg_buf_idx = 0;
   }   
   else if( err == 2 )
   { 
		 UART_msg_put("\n\rNot in DEBUG Mode!"); 
		 msg_buf_idx = 0;
	 }   
	
	 // put index to start of buffer for next message
	 msg_buf_idx = 0;
}


//*****************************************************************************
///   \fn   is_hex
/// Function takes 
///  @param a single ASCII character and returns 
///  @return 1 if hex digit, 0 otherwise.
///    
//*****************************************************************************
uchar8_t is_hex(uchar8_t c)
{
   if( (((c |= 0x20) >= '0') && (c <= '9')) || ((c >= 'a') && (c <= 'f'))  )
      return 1;
   return 0;
}

/*******************************************************************************
/// \fn void monitor(void)
/// \brief Function determines some action to perform based on display_mode.  The 8 
///   display modes operate as follows:
///
///  NORMAL MODE       Outputs only constant num 55 values
///
///  QUIET MODE        No Outputs
///
///  DEBUG MODE        Outputs only constant num 56 values
///
///  VERSION MODE      Outputs current version information
///
///  GENERAL MODE      Outputs error count, sensor information and ARM registers
/// 									 R0-R10, and R13-R15
///
///  MEM READ MODE     Outputs a memory segment from a given start address and end 
///                    address (inclusive of start and end addresses)
///										 
///  STACKTRACE MODE   Outputs the contents of the top 15 stack addresses
///
///  HELP MODE   			 Outputs available Modes and their short descriptions
///
/// There is deliberate delay in switching between modes to allow the RS-232 cable 
/// to be plugged into the header without causing problems. 
*******************************************************************************/
void monitor(void)
{

/**********************************/
/*     Spew outputs               */
/**********************************/

   switch(display_mode)
   {
      case(QUIET):
         {
             UART_msg_put("\r\n ");
             display_flag = 0;
         }  
         break;
      case(VERSION):
         {
             display_flag = 0;
         }  
         break;         
      case(NORMAL):
         {
            if (display_flag == 1)
            {
							 char buffer[64];
               UART_msg_put("\r\nNORMAL ");
							
							 sprintf(buffer,"Flow: %u", 55);
               UART_msg_put(buffer);
							 
							 sprintf(buffer," Temp: %u", 55);
               UART_msg_put(buffer);
							
							 sprintf(buffer," Freq: %0u", 55);
               UART_msg_put(buffer);							
               display_flag = 0;
            }
         }  
         break;
      case(DEBUG):
         {
            if (display_flag == 1)
            {
							 char buffer[64];
							
               UART_msg_put("\r\nDEBUG ");
							 
							 sprintf(buffer,"Flow: %u", 56);
               UART_msg_put(buffer);
							
							 sprintf(buffer," Temp: %u", 56);
               UART_msg_put(buffer);
							
							 sprintf(buffer," Freq: %0u", 56);
               UART_msg_put(buffer);							
               
						}
						display_flag = 0;
						break;
					}
			case (GENERAL):
				{
					
					if (display_flag == 1)
            {
							 char buffer[64];
							
               UART_msg_put("\r\nGENERAL ");
							 
							 // display errors
							sprintf(buffer,"\r\nError Count: %d",error_count);
							UART_direct_msg_put(buffer);
							
							
							// display sensor states?
							
							sprintf(buffer,"\r\nSensor 0: %d",4);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nSensor 1: %d",5);
							UART_direct_msg_put(buffer);
							
							
							// display registers
							sprintf(buffer,"\r\nR0: %d",R0);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR1: %d",R1);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR2: %d",R2);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR3: %d",R3);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR4: %d",R4);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR5: %d",R5);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR6: %d",R6);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR7: %d",R7);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR8: %d",R8);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR9: %d",R9);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR10: %d",R10);
							UART_direct_msg_put(buffer);
							
//							sprintf(buffer,"\r\nR11: %d",R0);
//							UART_msg_put(buffer);
//							
//							sprintf(buffer,"\r\nR12: %d",R0);
//							UART_msg_put(buffer);
							
							sprintf(buffer,"\r\nR13: %d",R13);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR14: %d",R14);
							UART_direct_msg_put(buffer);
							
							sprintf(buffer,"\r\nR15: %d",R15);
							UART_direct_msg_put(buffer);
							
               
						}
						// clear flag to ISR
						display_flag = 0;
						break;                          				
         }
		  //  Create a command to read a section of Memory and display it
			case (MEMREAD):
				{
					if (display_flag == 1)          
					{
//						char buf[11];
//						uchar8_t j;
						int start = 0;
						int end = 0;

						int idx;
						for(idx = 0; idx < 8; idx++)
						{	
								// shift old val to the left, or in new hex val								
								start = start << 4 | asc_to_hex(startbuf[idx]);
								end = end << 4 | asc_to_hex(endbuf[idx]);
						}
							
						//UART_direct_msg_put(msg_buf);
						
						char buffer[128];
						int* reg =     (int*) start;
						int* reg_end = (int*) end;

						while( reg <= reg_end )
						{
							sprintf(buffer, "\r\nRegister: 0x%x, Value: 0x%x\n", reg, *reg);	
							UART_direct_msg_put(buffer);
							reg++;
						}				

					}
						
					// clear flag to ISR					
					display_flag = 0;				
					
					break;
         }
		//  Create a command to read 16 words from the current stack 
		// and display it in reverse chronological order.
		case (STACKTRACE):
			{
				
				if (display_flag == 1)
					{
						char buffer[64];
						uint32_t stack_contents = 512;
						int* stack_start = (int*) R13;
						for (uint8_t i = 0; i < 16; i++){
							// read the stack
							stack_contents = (uint32_t) *(stack_start - i);
							
							sprintf(buffer,"\r\nPointer: 0x%x| Value: %d: 0x%x",(stack_start - i), (15-i) ,stack_contents);
							UART_direct_msg_put(buffer);
						}
						 
					}
					 // clear flag to ISR
					display_flag = 0;
					break;          				
			 }
		case (HELP):
		{
			if(display_flag == 1)
			{
				set_display_mode();
				display_mode = QUIET;
			}
			
			display_flag = 0;
			break;
		}

      default:
      {
				UART_msg_put("Mode Error");
      }  
   }
}  
