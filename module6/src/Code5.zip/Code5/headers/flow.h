 /**----------------------------------------------------------------------------
             \file flow.h
--                                                                           --
--              ECEN 5003 Mastering Embedded System Architecture             --
--                  Project 1 Module 6                                       --
--                Microcontroller Firmware                                   --
--                         flow.h                                            --
--                                                                           --
-------------------------------------------------------------------------------
--
--  Designed for:  Project 1 Module 6
--               
--                
--  Designed by:  Michael Starks and Sovann Chak
-- 
-- Version: 1.0
-- Date of current revision:  2023-10-20   
-- Target Microcontroller: ST STM32F401RE 
-- Tools used:  ARM mbed compiler
--              ARM mbed SDK
--              ST Nucleo STM32F401RE Board
--               
-- 
   Functional Description: See below 
--
--      Copyright (c) 2015, 2022 Tim Scherr All rights reserved.
--
*/   

#ifndef FLOW_H
#define FLOW_H

/** Instantenous velocity of fluid in meters per sec **/
#define INST_VELOCITY 10  			 /* constant value for instant velocity */
#define PID 2.9f 				  			 /* constant value for pipe inner diameter */
#define PID_METERS (2.9f / 39.37f) /* constant value for pipe inner diameter (meter conv) */
#define BLUFF_BODY (0.5f / 39.37f) /* constant value for bluff body (meter conv) */

 float flow(float v); 												/* located in module flow.c */
 float volumetric_flow_rate(float f); 				/* located in module flow.c */
 float viscosity(float t); 										/* located in module flow.c */
 float rho(float t); 												  /* located in module flow.c */
 float reynolds(float d, float v, float vis); /* located in module flow.c */
 float strouhal(float re);  									/* located in module flow.c */
 
#endif
