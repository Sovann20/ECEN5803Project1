var searchData=
[
  ['freq_5fdata_0',['freq_data',['../main_8cpp.html#a799c46e7927be87df94a4a95d59744c0',1,'main.cpp']]]
];
