var searchData=
[
  ['of_20colorado_20at_20boulder_0',['of colorado at boulder',['../main_8cpp.html#autotoc_md7',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../_monitor_8cpp.html#autotoc_md13',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../shared_8h.html#autotoc_md19',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../timer0_8cpp.html#autotoc_md25',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder'],['../_u_a_r_t__poll_8cpp.html#autotoc_md30',1,'&amp;ndash;  Designed for:  University of Colorado at Boulder']]],
  ['os_1',['&amp;ndash;                           modified to implement a super loop bare metal OS.',['../main_8cpp.html#autotoc_md10',1,'']]]
];
