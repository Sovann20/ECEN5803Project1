var searchData=
[
  ['flip_0',['flip',['../main_8cpp.html#a126cb0362ae2e7935520fb27343bad31',1,'main.cpp']]],
  ['frequency_1',['frequency',['../main_8cpp.html#ab02a1f1017896d97cdad3eb9159fb89a',1,'main.cpp']]]
];
