var searchData=
[
  ['serial_0',['serial',['../shared_8h.html#a44becc30285e88213a624428b2b46cdf',1,'serial(void):&#160;UART_poll.cpp'],['../_u_a_r_t__poll_8cpp.html#a44becc30285e88213a624428b2b46cdf',1,'serial(void):&#160;UART_poll.cpp']]],
  ['setup_5ftemp_5fsensor_1',['setup_temp_sensor',['../main_8cpp.html#ad0bd26ebc0a505887d5a58b7c5f6929b',1,'main.cpp']]]
];
