var searchData=
[
  ['implement_20a_20super_20loop_20bare_20metal_20os_0',['&amp;ndash;                           modified to implement a super loop bare metal OS.',['../main_8cpp.html#autotoc_md10',1,'']]],
  ['in_20the_20transmit_20buffer_1',['&amp;ndash;       UART_hex_put() - a routine that puts a hex byte in the transmit buffer',['../_u_a_r_t__poll_8cpp.html#autotoc_md33',1,'']]]
];
