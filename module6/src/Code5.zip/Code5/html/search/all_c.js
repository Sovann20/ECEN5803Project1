var searchData=
[
  ['loop_20bare_20metal_20os_0',['&amp;ndash;                           modified to implement a super loop bare metal OS.',['../main_8cpp.html#autotoc_md10',1,'']]]
];
