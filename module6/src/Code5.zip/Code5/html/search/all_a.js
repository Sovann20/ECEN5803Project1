var searchData=
[
  ['header_20file_20for_20all_20globals_0',['&amp;ndash; Functional Description:  Header file for all globals',['../shared_8h.html#autotoc_md22',1,'']]],
  ['hex_20byte_20in_20the_20transmit_20buffer_1',['&amp;ndash;       UART_hex_put() - a routine that puts a hex byte in the transmit buffer',['../_u_a_r_t__poll_8cpp.html#autotoc_md33',1,'']]]
];
