var searchData=
[
  ['globals_0',['&amp;ndash; Functional Description:  Header file for all globals',['../shared_8h.html#autotoc_md22',1,'']]]
];
