var searchData=
[
  ['readadc_0',['readADC',['../main_8cpp.html#a63dd01341d3566ea779f7597d942a846',1,'main.cpp']]],
  ['readvref_1',['readVREF',['../main_8cpp.html#a8e9552c996fb6a98c70de0aa19e35cc3',1,'main.cpp']]]
];
