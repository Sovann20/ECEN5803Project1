/**----------------------------------------------------------------------------
             \file flow.cpp
--                                                                           --
--              ECEN 5003 Mastering Embedded System Architecture             --
--                  Project 1 Module 6                                       --
--                Microcontroller Firmware                                   --
--                       flow.cpp                                            --
--                                                                           --
-------------------------------------------------------------------------------
--
--  Designed for:  Project 1 Module 6
--               
--                
--  Designed by:  Michael Starks and Sovann Chak
-- 
-- Version: 1.0
-- Date of current revision:  2023-10-20   
-- Target Microcontroller: ST STM32F401RE 
-- Tools used:  ARM mbed compiler
--              ARM mbed SDK
--              ST Nucleo STM32F401RE Board
--               
-- 
   Functional Description: See below 
--
--      Copyright (c) 2015, 2022 Tim Scherr All rights reserved.
--
*/              

#include "shared.h"
#include "flow.h"
#include <cmath>

//*****************************************************************************/
/// \fn void flow()
///
///  \brief - Calculates flow in gallons/minute given some velocity
/// 
///  \param v Velocity in feet/second 
///           
//*****************************************************************************/
float flow(float v)
{
    return (float) 2.45f * (PID * PID) * (v * 3.28084f);
}

//*****************************************************************************/
/// \fn void volumetric_flow_rate()
///
///  \brief - Calculates the volumetric flow rate given a frequency of vortex 
///						shedding times the width of bluff body (constant) and then dividing 
/// 					by a Strouhal number
/// 
///  \param f Frequency of vortex shedding
///           
//*****************************************************************************/
float volumetric_flow_rate(float f)
{								
		// convert celsius to kelvin
    float temp_k = 237.15f + temperature;
    
	  // run various calculations which are necessary to
	  // obtain strouhal number
		float vis = viscosity(temp_k);
    float r   = rho(temperature);
    float re  = reynolds(r, INST_VELOCITY, vis);
    float st  = strouhal(re);
    
    return f*BLUFF_BODY/st;
} 

//*****************************************************************************/
/// \fn void viscosity()
///
///  \brief - Calculates viscosity given some temperature in kelvin
/// 
///  \param t Temperature in kelvin
///
//*****************************************************************************/
float viscosity(float t)
{
    float exp = (247.8f/(t-140.0f));
    return 0.000024f * powf(10, exp);
}

//*****************************************************************************/
/// \fn void rho()
///
///  \brief - Calculates density given some temperature in celcius
///           
///  \param t Temperature in celsius 
//*****************************************************************************/
float rho(float t)
{
   return 1000*(1 - ((t+288.9414f)/(508929.2f*(t+68.12963f)))*pow((t-3.9863f),2));
}


//*****************************************************************************/
/// \fn void reynolds()
///
///  \brief - Calculates Reynolds number given a density, velocity, and
///						viscosity.
///
///	 \param d   Density in kg/m^3
///
///	 \param v   Velocity in m/s
///
///	 \param vis Viscosity in kg/(m*s)
///
///           
//*****************************************************************************/
float reynolds(float d, float v, float vis)
{
    return (d * v * PID_METERS)/vis;
}

//*****************************************************************************/
/// \fn void strouhal()
///
///  \brief - Calculates a Strouhal number given a reynolds number
///
///	 \param re Reynolds number
///           
//*****************************************************************************/
float strouhal(float re)
{
    return (0.2684f - 1.0356f/sqrtf(re));
}
