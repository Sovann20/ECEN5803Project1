// File: main.c
// Description: This file contains the C functions to copy (my_strcpy) 
// and capitalize (my_capitalize) strings. 
// Authors: Michael Starks and Sovann Chak
// Tools: Keil uVision with Compiler version 5

void my_strcpy(char* s1, char* s2)
{
    int i = 0;

    while(1)
    {
        s2[i] = s1[i];

        if(s1[i] == '\0')
        {
            return;
        }
		i++;
    }
}

void my_capitalize(char* s)
{
    int i=0;
    while(1)
    {
        if(s[i] > 'a' && s[i] <= 'z' )
        {
            s[i] = s[i]-32;
        }

        if(s[i] == '\0')
        {
            return;
        }
        i++;
    }
}

int main(void)
{
	const char a[] = "Hello world!";
  char b[20];

  my_strcpy((char*) a, b);
  my_capitalize(b);
    
  while (1);
}