// File: main.c
// Description: This file contains an assembly function to find the square root of an integer
// Authors: Michael Starks and Sovann Chak
// Tools: Keil uVision with Compiler version 5


/**
 * A function that takes in an int that the user would like to find the square root of
 * and returns the closest int to the square root.
 * @param x The number the user would like to find the square root of
 * @return The closet int to the square root
 */
__asm int my_sqrt(int x)
{
	// Store the stack pointer and register states
	PUSH {R4, R5, R6, R7, R8, R10, R11, R12, lr}; // Push LR to regiter for safe keeping
			
	// Function start
	MOV R4, #0x0; // Move the value 0 into A (R0)
	MOV R5, #0x010000; // Move the value 256 (0x100) in B (R1)
	MOV R6, #0xFFFFFFFF; // Move the value -1 (0xFFFFFFFF) into C (R2)
	MOV R7, #0x0; // Store 0 in C_OLD
	MOV R8, #0x0; // Holds DONE value for loop condition
	MOV R1, #0xFFFFFFFE; // Holds the value -2 
	MOV R2, #0x0; // Holds the value 0
    
// Start of the LOOP
LOOP 							
	MOV R7, R6; // Store the value of C (R6) in C_OLD (R7)
	ADD R3, R4, R5; // Add A (R4) and B (R5) and store in R9 
	MOV R10, #0x2 // Store 2 (0x2) in R10
	SDIV R6, R3, R10; // Divide the value in R9 by R10 (holding 2) and place in C (R6)
	MUL R11, R6, R6; // C^2 and place in R10
	SUB R11, R11, R0; // Subtract X (R0) from C^2
	SUB R11, R11, #0x1; // Subtract 1 from (C^2 - X)
		
	// Check if the value in R11 is less than negative 2
	CMP R11, R1; // Compare the value in R11 to -2
	BLT LESS; // Branch if less than
	CMP R11, R2; // Compare the value in R11 to -1
	BGT GREATER // Branch if greater than
	B END;	// Else
		

LESS 
	MOV R4, R6; // Move C (Stored in R6) to A (Stored in R4)
	CMP R6, R7; // Compare to see if C == OLD_C
	BEQ END;
	// Condition TRUE
	BNE LOOP// Branch to LOOP

GREATER
	MOV R5, R6; // Move C (Stored in R6) to B (Stored in R5)
	CMP R6, R7;  
	BEQ END; 	// Condition TRUE
	BNE LOOP; // Branch to LOOP


// Loop has ended
END
	MOV R0, R6;// Move C to return register (R0)
	POP {R4, R5, R6, R7, R8, R10, R11, R12, pc}; // Pop contents of registers off the stack and resume program
}

/**
 * Main function for testing sqrt function.
 * @return return SUCCESS
 */

int main(void)
{
	volatile int r, j = 0;
	int i;
	r = my_sqrt(2);  // Should be 1
	r = my_sqrt(4); // Should be 2
	r = my_sqrt(22);   // Should be 4
	r = my_sqrt(121);   // Should be 4
	
	for (i = 0; i < 10000; i++) {
		r = my_sqrt(i);
		j += r;
	}
	
	while (1);
	return 0;
}

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
