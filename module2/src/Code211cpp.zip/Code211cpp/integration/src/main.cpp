/*----------------------------------------------------------------------------
LAB EXERCISE 11.4- SPI and I2C interface
SERIAL COMMUNICATION
 ----------------------------------------
 Display the temperature from the virtual DS1631 temperature sensor on the 
      virtual LCD
 
 Input: virtual DS1631 temperature sensor
 Output: virtual LCD display
	
	GOOD LUCK!
 *----------------------------------------------------------------------------*/

#include "NHD_0216HZ.h"
#include "DS1631.h"
#include "pindef.h"

//Define the LCD and the temperature sensor

//Write your code here

DS1631 temp_sensor(I2C_SDA,I2C_SCL,0x90);
NHD_0216HZ display(SPI_CS,SPI_MOSI,SPI_SCLK);

//Define a variable to store temperature measurement
float temp;

/*----------------------------------------------------------------------------
 MAIN function
 *----------------------------------------------------------------------------*/

int main() {
	//Initialise the LCD
	
	//Write your code here
	wait(5);
	display.init_lcd();
	display.printf("Hello World!");
	wait_ms(50);
	
	
	
	while(1){
		/*
		Read the temperature from the DS1631
		Update the LCD with new temperature measurement
		*/
		
		//Write your code here
	display.clr_lcd();
	display.set_cursor(0,0);
	temp = temp_sensor.read();
	display.printf("Temperature:");
	display.set_cursor(0,1);
	display.printf("%0.2f",temp);
	printf("Temperature: %0.2f\r\n", temp);
		
	}
}

// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
