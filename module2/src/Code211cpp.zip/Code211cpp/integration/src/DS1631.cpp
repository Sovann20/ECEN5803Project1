/*----------------------------------------------------------------------------
 MAXIM DS1631 2-wire temperature sensor library
 *----------------------------------------------------------------------------*/

#include "mbed.h"
#include "DS1631.h"

int ret = 0; 
char reset_cmd[1] = {0x54};
char cmd[] = {0xAA};
char read_temp[2];
char stop_reading = 0x22;
char start_convert = 0x51;

DS1631::DS1631(PinName sda, PinName scl, int addr) : temp_sensor(sda, scl), _addr(addr){

}

float DS1631::read(){
	
	temp_sensor.write(_addr,&start_convert,1,false);
	
		/*
		Write the Start Convert T command to the sensor
		Write the Read Temperature command to the sensor
		Read the 16-bit temperature data
		*/
		
		//Write your code here
		
		do {
			ret = temp_sensor.write(_addr,cmd,1);
		} while (ret != 0);
		
		
		ret = temp_sensor.read(_addr,read_temp,2);
		
		//Convert temperature to Celsius
	float temp = (float((read_temp[0] << 8) | read_temp[1]) / 256);
	
	return temp;

//	temp_sensor.write(_addr, &cmd[0], 1);
//	//wait(0.5);
//	temp_sensor.write(_addr, &cmd[1], 1);
//	temp_sensor.read(_addr,read_temp,2);
//	
//	
//	float temp = (float((read_temp[0] << 8) | read_temp[1]) / 256);
//	
//	return temp;


}
// *******************************ARM University Program Copyright (c) ARM Ltd 2014*************************************
